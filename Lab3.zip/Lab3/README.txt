Group 07 Lab 3 Submission
Harley Wiltzer (260690006)
Spiros-Daniel Mavroidakos (260689391)
=====================================
This README will serve as a guide to the files of interest.

The stack circuit: g07_stack.bdf (and g07_stack.vhd)
The testbed code: g07_testbed.vhd
The testbed diagram: g07_testbed_diagram.bdf
The Mod13 circuit: mod13.vhd
The pushpopdecide circuit (see stack): g07_pushpopdecide.vhd
The generator circuit (see stack): g07_generator.vhd
The debouncer circuit: g07_debounder.bdf

The Lab Report: Report.pdf

NOTE: The Lab3/ directory stores old simulation results crucial to the
development of the circuits in this lab. This directory includes some media
required for compiling the Report.tex file, but does not contain any important
information concerning this lab. The Report.pdf file, of course, has already
been compiled.
